#ifndef __SIZE_T_H
#define	__SIZE_T_H


#ifdef __cplusplus
extern "C"
{
#endif

/* standard size_t type */
typedef unsigned size_t;

#ifdef __cplusplus
}
#endif


#endif